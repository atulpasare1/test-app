@extends('layouts.admin')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">
     <div class="row g-6 mb-6 justify-content-end">

      <div class="col-sm-4 d-grid ">
        <div class="card-header border-bottom">
            <div class="d-flex justify-content-between">
                <div class="me-1">
                    <h5 class="card-title mb-0">create Quiz</h5>
                    <small class="text-muted"> You can manage Quiz From here</small>
                </div>
               
              </div>
          
           
          
        </div>
      </div>
      <div class="col-sm-2 d-grid">
        <a  class="btn btn-outline-secondary waves-effect">
            <div class="d-flex justify-content-start align-items-center user-name">
                <div class="avatar-wrapper">
                   <div class="avatar avatar-sm me-0 mt-2">
                    <i class=" ri-sun-line"></i>
                   </div>
                </div>
                <div class="d-flex flex-column">
                    <span>Details</span>
                    
                </div>
             </div>
         
        </a>
         </div>
      <div class="col-sm-2 d-grid">

         <a  class="btn btn-outline-secondary waves-effect">
            <div class="d-flex justify-content-start align-items-center user-name">
                <div class="avatar-wrapper">
                   <div class="avatar avatar-sm me-0 mt-2">
                    <i class=" ri-setting"></i>
                   </div>
                </div>
                <div class="d-flex flex-column">
                    <span>Settings</span>
                    
                </div>
             </div>
         
        </a>
      </div>
      <div class="col-sm-2 d-grid">
         <a  class="btn btn-outline-secondary waves-effect">
            <div class="d-flex justify-content-start align-items-center user-name">
                <div class="avatar-wrapper">
                   <div class="avatar avatar-sm me-0 mt-2">
                    <i class=" ri-sun-line"></i>
                   </div>
                </div>
                <div class="d-flex flex-column">
                    <span>Questions</span>
                    
                </div>
             </div>
         
        </a>
      </div>
      <div class="col-sm-2 d-grid">
         <a  class="btn btn-outline-secondary waves-effect">
            <div class="d-flex justify-content-start align-items-center user-name">
                <div class="avatar-wrapper">
                   <div class="avatar avatar-sm me-0 mt-2">
                    <i class=" ri-sun-line"></i>
                   </div>
                </div>
                <div class="d-flex flex-column">
                    <span>Schedules</span>
                    
                </div>
             </div>
         
        </a>
      </div>
    
    </div>
    <!-- {{$title}}  List Table -->
    <div class="card">
       
        
        <!-- Offcanvas to add new user -->
     </div>
    
    
              </div>
@endsection